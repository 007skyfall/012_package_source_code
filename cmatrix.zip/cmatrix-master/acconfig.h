/* Define this if your curses library has use_default_colors, for 
   cool transparency =-) */
#undef HAVE_USE_DEFAULT_COLORS

/* Define this if you have the linux consolechars program */
#undef HAVE_CONSOLECHARS

/* Define this if you have the linux setfont program */
#undef HAVE_SETFONT

/* Define this if you have the wresize function in your ncurses-type library */
#undef HAVE_WRESIZE

/* Define this if you have the resizeterm function in your ncurses-type library */
#undef HAVE_RESIZETERM

